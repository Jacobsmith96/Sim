package driver;

import classes.Game;
public class Driver extends java.applet.Applet{
	//The main driver of the program
	
	public static void main(String[] args){
		Game game = new Game();
		game.create();
	}
}
