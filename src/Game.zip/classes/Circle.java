package classes;
import java.awt.Graphics;
public class Circle{
	public int xVal; //xpos
	public int yVal; //ypos
	public int r; //radius	
	public int midX; //midpoint x
	public int midY; //midpoint y
	public int angle = 0;
	double slope = 0;
	public int dist=1;
	public boolean jumping = false;
	public boolean falling = false;
	public boolean movingClock = false;
	public boolean movingCounter = false;
	public boolean canJump = true;
	public Circle(){
		xVal = 0;
		yVal = 0;
		r = 50;
		midX = 25;
		midY = 25;
	}
	public Circle(int x, int y, int rad){
		xVal = x;
		yVal = y;
		r = rad;
		midX = x+rad;
		midY = y+rad;
	}
	public Circle(String y, int rad){
		if(y.equals(y))
		xVal = 400-150;
		yVal = 400-150;
		r=rad;
		midX = 400;
		midY = 400;
	}
	public int getX(){
		return xVal;
	}
	public int getY(){
		return yVal;
	}
	public int getRadius(){
		return r;
	}
	public int getMidX(){
		return midX;
	}
	public int getMidY(){
		return midY;
	}
	public void paintCircle(Graphics g){
		g.drawOval(getX(),getY(),2*getRadius(),2*getRadius());
	}
	public void paintPlayer(Graphics g){
		g.drawOval(getMidX()-25,getMidY()-25,2*getRadius(),2*getRadius());
	}
	public void paintEnemy(Graphics g){
		g.drawOval(getMidX()-10,getMidY()-10,2*getRadius(),2*getRadius());
	}
	public void moveClock(){
		angle-=2;
		midX=(int)(Math.cos(angle/57.2957795)*(150+getRadius()+dist))+400;
		xVal=midX-25;
		midY=(int)(Math.sin(angle/57.2957795)*(150+getRadius()+dist))+400;
		yVal=midY-25;
	}
	public void moveCounter(){
		angle+=2;
		midX=(int)(Math.cos(angle/57.2957795)*(150+getRadius()+dist))+400;
		xVal=midX-25;
		midY=(int)(Math.sin(angle/57.2957795)*(150+getRadius()+dist))+400;
		yVal=midY-25;
	}
	public void jumping(){
		dist+=3;
		midX=(int)(Math.cos(angle/57.2957795)*(150+getRadius()+dist))+400;
		xVal=midX-25;
		midY=(int)(Math.sin(angle/57.2957795)*(150+getRadius()+dist))+400;
		yVal=midY-25;
	}
	public void falling(){
		if(dist>1)
		dist-=3;
		midX=(int)(Math.cos(angle/57.2957795)*(150+getRadius()+dist))+400;
		xVal=midX-25;
		midY=(int)(Math.sin(angle/57.2957795)*(150+getRadius()+dist))+400;
		yVal=midY-25;
	}
	public void update(){
		if(movingClock){
			moveClock();
		}
		else if(movingCounter){
			moveCounter();
		}
		if(jumping){
			jumping();
		}
		else if(falling){
			falling();
		}
		if(dist <2){
			falling = false;
			jumping = false;
			canJump = true;
		}
		else if(dist>50){
			falling = true;
			jumping = false;
			canJump = false;
		}
	}
	public int distance(Circle circ1){
		return (int)Math.sqrt(Math.pow(circ1.getMidX()-getMidX(),2)+Math.pow(circ1.getMidY()-getMidY(),2));
	}
	public boolean collision(Circle circ1){
		
		double a = getRadius()+circ1.getRadius();
		double dx = (getMidX() - circ1.getMidX());
		double dy = (getMidY() - circ1.getMidY());
		return a * a > ((dx*dx) + (dy*dy));

	}
}
