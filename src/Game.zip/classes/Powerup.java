package classes;

public class Powerup extends Point{
	public Powerup(){
		dist = 600;
		angle = (int)(Math.random()*360);
		midX=(int)(Math.cos(angle/57.2957795)*(dist))+400;
		xVal=midX-15;
		midY=(int)(Math.sin(angle/57.2957795)*(dist))+400;
		yVal=midY-15;
		fallingSpeed = 1;
		r = 15;

	}
}
