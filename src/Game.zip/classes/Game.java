package classes;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;

import javax.swing.Timer;
import javax.swing.JFrame;
import javax.swing.JPanel;  
import javax.swing.WindowConstants;


public class Game extends JFrame implements ActionListener, KeyListener
{
	boolean running; //States whether the game is still running or not
	Circle circ1; //Middle circle of the game
	Circle player; //Player controlled circle
	JPanel panel; //Background panel
	Timer timer; //Initializes the timer
	ActionListener action;
	ArrayList keys = new ArrayList(); 
	public int tick = 0;
	ArrayList<Point> points = new ArrayList<Point>();
	ArrayList<Enemy> enemies = new ArrayList<Enemy>();
	ArrayList<Powerup> powerups = new ArrayList<Powerup>();
	public int score = 0;
	public String input;
	public int enemyCount = 0;
	public Game(){
		running = false; //Sets the game to running
		panel = new JPanel(); //Instantiates the panel
		setContentPane(panel); 
		panel.setOpaque(true);
		panel.setDoubleBuffered(true);
		circ1 = new Circle("y",150); //Instantiates the Middle circle
		player = new Circle(550,375,25); //Instantiates the player controlled circle
		timer = new Timer(40, this);
		setFocusable(true);
		addKeyListener(this);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}
	public void run(){
		running = true;
		timer.start();
	}
	public void actionPerformed(ActionEvent e){
		for(Enemy a : enemies){
			if(tick%3==0)
				a.moveRandom();
			if(player.collision(a))
			die();
		}
		for(int a = 0;a<points.size();a++){
			if(points.get(a).dist<150 + points.get(a).getRadius()){
				points.remove(a);
				if(score>=0)
				score--;
			}
			if(player.collision(points.get(a)))
			{
				if(points.get(a).getType()==0){
					score++;
				}
				else if(points.get(a).getType()==1){
					score+=2;
				} 
				else if(points.get(a).getType()==2){
					score+=3;
				}
				points.remove(a);
				a--;
				if(score>4){
					enemyCount++;
				}
				else if(score>9){
					enemyCount++;
				}
				else if(score>14){
					//enemies.get(0).seekPlayer(player){
						
					//}
				}
			}
			else
			points.get(a).fall();
			
		}
		if(enemies.size()<enemyCount){
			enemies.add(new Enemy());
		}
		player.update();
		repaint();
		System.out.println(keys);
		if(tick%99==0){
			points.add(new Point());
		}
		if(tick==999){
			powerups.add(new Powerup());
		}
		if(tick<1000){
			tick++;
		}
		else
			tick = 0;
	}
	public void create(){
		setSize(800,800);
		show();
		repaint();
		run();
	}
	public void paint(Graphics g){
		super.paint(g);
		if(running){
			g.setColor(Color.BLACK);
			g.fillRect(0, 0, 800, 800);
			g.setColor(Color.BLUE);
			circ1.paintCircle(g);
			g.setColor(Color.YELLOW);
			player.paintPlayer(g);
			g.setColor(Color.RED);
			for(Enemy a : enemies){
				a.paintEnemy(g);
			}
			for(Point a : points){
				if(a.type==0){
					g.setColor(Color.GREEN);
					a.paintCircle(g);
				}
				else if(a.type==1){
					g.setColor(Color.BLUE);
					a.paintCircle(g);
				}
				else if(a.type==2){
					g.setColor(Color.WHITE);
					a.paintCircle(g);
				}
			}
			g.setColor(Color.WHITE);
			g.setFont(new Font("Arial", Font.PLAIN, 20));
			g.drawString("Score:" + score, 10,50);
		}
		else{
			g.fillRect(0, 0, 800, 800);
			g.setColor(Color.BLUE);
			circ1.paintCircle(g);
			g.setColor(Color.YELLOW);
			player.paintPlayer(g);
			g.setColor(Color.RED);
			for(Enemy a : enemies){
				a.paintEnemy(g);
			}
			g.setColor(Color.GREEN);
			for(Point a : points){
				a.paintCircle(g);
			}
			g.setColor(Color.WHITE);
			g.setFont(new Font("Arial", Font.PLAIN, 20));
			g.drawString("GAME OVER", 340,400);
			g.drawString("Your Score: " + score, 340,425);
		}
		//g.drawLine(circ1.getMidX(),circ1.getMidY(),player.getMidX(),player.getMidY());
	}
	public void keyPressed(KeyEvent e) {
		int key = e.getKeyCode();
		if(!keys.contains(key))
			keys.add(key);
		if(keys.contains(KeyEvent.VK_SPACE)&&player.canJump){
			player.jumping = true;
		}
		if(keys.contains(KeyEvent.VK_RIGHT)){
			player.movingCounter=true;
		}
		if(keys.contains(KeyEvent.VK_LEFT)){
			player.movingClock=true;
		}
	}

	public void keyReleased(KeyEvent e) {
		int key = e.getKeyCode();
		if(keys.size()>0)
		keys.remove(keys.indexOf(key));
		if(key == KeyEvent.VK_SPACE){
			player.jumping = false;
			player.canJump = false;
			player.falling= true;
		}
		if(key == KeyEvent.VK_RIGHT){
			player.movingCounter=false;
		}
		else if(key == KeyEvent.VK_LEFT){
			player.movingClock=false;
		}
	}

	public void keyTyped(KeyEvent e) {
	}
	public void die(){
		running = false;
		timer.stop();
		repaint();
	}
	public int getTick(){
		return tick;
	}
}



