package classes;

public class Enemy extends Circle{
	int enemyAngle;
	public Enemy(){
		enemyAngle = (int)(Math.random()*360);
		angle = enemyAngle;
		midX=(int)(Math.cos(angle/57.2957795)*(160))+400;
		xVal=midX-10;
		midY=(int)(Math.sin(angle/57.2957795)*(160))+400;
		yVal=midY-10;
		r = 10;
	}
	public void moveRandom(){
		int ran = (int)(Math.random()*3);
		if(ran == 1){
			moveClock();
		}
		else if(ran == 2){
			moveCounter();
		}
		else
			return;
	}
	public void seekPlayer(Circle circ1){
		
	}
}
